package dataStructure;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;



import Server.Game_Server;
import Server.game_service;
import algorithms.Graph_Algo;
import algorithms.graph_algorithms;
import gameClient.fruit;
import gameClient.Ex4_Client;
import gameClient.MyGameGUI;
import gameClient.SimpleDB;
import gameClient.play;
import gameClient.robot;
import oop_dataStructure.oop_edge_data;
import oop_dataStructure.oop_graph;

import utils.Point3D;


public class test {

	public static void main(String[] args) {
		
			//int id = 206087702;
			//Game_Server.login(206087702);	
		//	Game_Server.login(206087702);
			MyGameGUI h = new MyGameGUI(); 
		//	SimpleDB.printLog();
			//String kml = Ex4_Client.getKML(206087702 , 0);
			//System.out.println(kml);
				
	}
}
